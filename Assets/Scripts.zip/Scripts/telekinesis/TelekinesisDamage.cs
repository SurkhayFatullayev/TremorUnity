using UnityEngine;

public class TelekinesisDamage : MonoBehaviour
{
    private float damage = 0f;

    public void SetDamage(float chargeTime)
    {
        damage = Mathf.Clamp(chargeTime * 10f, 5f, 50f); // Damage scales with charge
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy")) // Ensure enemies have the "Enemy" tag
        {
            Debug.Log($"⚡ TeleObject {gameObject.name} hit enemy: {collision.gameObject.name}!");

            // (Optional) If enemy has a health system, apply damage
            EnemyHealth enemyHealth = collision.gameObject.GetComponent<EnemyHealth>();
            if (enemyHealth != null)
            {
                enemyHealth.TakeDamage(damage);
            }

            // Destroy object after impact (Optional)
            Destroy(gameObject, 1f);
        }
    }
}
